#include <iostream>
#include "NStack.h"

using namespace std;

NStack::NStack(void)
{
	data = NULL;
}

NStack::NStack(NStack& another)
{

}

NStack::~NStack()
{
	ItemType *t, *s;
	t = data;
	while(t != NULL) {
		s = t;
		t = t->next;
		delete s;
	}
}

void	NStack::print(string title)
{
	ItemType *t;

	cout << title << ": ";
	t = data;
	while(t != NULL) {
		cout << t->item << ' ';
		t = t->next;
	}
	cout << endl;
}

bool	NStack::nmPush(int f, int b, string it)
{

}

bool	NStack::nmPop(int f, int b, string& it)
{

}