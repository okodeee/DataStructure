// ItemType.h StackDriver
const int MAX_ITEMS = 100;
typedef int ItemType;