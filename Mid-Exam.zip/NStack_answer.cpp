#include <iostream>
#include "NStack.h"

using namespace std;

NStack::NStack(void)
{
	data = NULL;
}

NStack::NStack(NStack& o)
{
	ItemType* t, * iter, * iter2, * prev;

	if (o.data == NULL) {
		data = NULL;
		return;
	}
	t = new ItemType;
	t->item = (o.data)->item;
	t->back = NULL;
	t->next = NULL;
	data = t;
	iter = (o.data)->next;
	prev = data;

	while (iter != NULL) {
		t = new ItemType;
		t->item = iter->item;
		t->back = prev;
		t->next = NULL;

		prev->next = t;
		prev = t;
		iter = iter->next;
	}
}

NStack::~NStack()
{
	ItemType* t, * s;
	t = data;
	while (t != NULL) {
		s = t;
		t = t->next;
		delete s;
	}
}

void	NStack::print(string title)
{
	ItemType* t;

	cout << title << ": ";
	t = data;
	while (t != NULL) {
		cout << t->item << ' ';
		t = t->next;
	}
	cout << endl;
}

bool	NStack::nmPush(int f, int b, string it)
{
	ItemType* t, * t2, * prev;

	if (b > f) return false;
	t = data;
	prev = NULL;
	for (int i = 0; i < f; i++) {
		if (t == NULL) return false;
		prev = t;
		t = t->next;
	}
	for (int i = 0; i < b; i++) {
		if (t == NULL) return false;
		prev = prev->back;
		t = t->back;
	}
	t2 = new ItemType;
	t2->item = it;
	if (data == NULL) {
		t2->back = t2->next = NULL;
		data = t2;
		return true;
	}
	t2->next = t;
	t2->back = prev;
	if (t == NULL) prev->next = t2;
	else t->back = t2;
	if (prev == NULL) {
		data = t2;
	}
	else {
		prev->next = t2;
	}

	return true;
}

bool	NStack::nmPop(int f, int b, string& it)
{
	ItemType* t, * t2, * prev;

	if (b > f) return false;
	t = data;
	prev = NULL;
	for (int i = 0; i < f; i++) {
		if (t == NULL) return false;
		prev = t;
		t = t->next;
	}
	for (int i = 0; i < b; i++) {
		if (t == NULL) return false;
		prev = prev->back;
		t = t->back;
	}
	if (t == NULL) return false;
	it = t->item;
	if (prev == NULL) {
		data = t->next;
		if (t->next != NULL) t->next->back = NULL;
	}
	else {
		if (t->next != NULL) {
			prev->next = t->next;
			t->next->back = prev;
		}
		else prev->next = NULL;
	}
	delete t;
	return true;
}