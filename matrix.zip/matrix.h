#pragma once
using namespace std;  // ostream�� ���ؼ� �����


class Matrix {

public:

	Matrix() {

		for (int i = 0; i < 2; i++) {
			for (int j = 0; j < 2; j++) {
				matrix[i][j] = 0;
			}
		}

	}

	Matrix(int ff, int fs, int sf, int ss) {

		matrix[0][0] = ff;
		matrix[0][1] = fs;
		matrix[1][0] = sf;
		matrix[1][1] = ss;
	}

private:
	int matrix[2][2];

};