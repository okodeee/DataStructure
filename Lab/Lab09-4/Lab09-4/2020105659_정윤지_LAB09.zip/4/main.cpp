#include <iostream>
#include "TreeType.h"
using namespace std;

int main()
{
	TreeType example;

	example.InsertItem('k');
	example.InsertItem('d');
	example.InsertItem('o');
	example.InsertItem('a');
	example.InsertItem('f');
	example.InsertItem('x');
	example.InsertItem('z');

	cout << example.SingleParentCount() << endl;
}