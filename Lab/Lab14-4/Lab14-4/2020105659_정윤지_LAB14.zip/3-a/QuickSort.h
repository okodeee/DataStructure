#include "Student.h"


void QuickSortPointer(Student* values[], int first, int last);